#!/bin/sh

./start.sh --offline-logging --debug --debug-server-connect ${1+"$@"}
